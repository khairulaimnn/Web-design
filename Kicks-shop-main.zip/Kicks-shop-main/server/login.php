<?php 
//data that is needed to connect to MySQL 
  $db_hostname = 'localhost';
  $db_database = 'online_shop';
  $db_username = 'root';
  $db_password = '';
?>